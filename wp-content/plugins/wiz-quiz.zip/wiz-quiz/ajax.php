<?php

function wiz_update_result_database_mcq()
{
    global $wpdb;
    $quiz_id = $_POST['wizQuizData']['quiz_id'];
    $user_name = $_POST['wizQuizData']['user_name'];
    $current_time = time();
    $given_answer = $_POST['answer'];
    $question_id = $_POST['question_id'];
    $total_option = get_post_meta($question_id, 'mcq_options_', true);

    for ($i = 0; $i < $total_option; $i++) {
        $opt_key = 'mcq_options__' . $i . '_right';
        $opt_name = get_post_meta($question_id, $opt_key, true);
        if ($opt_name) {
            $actual_ans = get_post_meta($question_id, 'mcq_options__' . $i . '_mcq_option', true);
        }
    }
    if ($given_answer == $actual_ans) {
        $correct = true;
        $gain_point = 1;
    } else {
        $correct = false;
        $gain_point = 0;
    }

    $new_result = array(
        'question_id'  => $_POST['question_id'],
        'answer_given' => $_POST['answer'],
        'correct'      => $correct,
        'total_point'  => 1,
        'gain_point'   => $gain_point,
    );

    // Prepare SQL query to get the row from the database
    $table_name = $wpdb->prefix . "wiz_results";
    $query = "
        SELECT * 
        FROM $table_name 
        WHERE quiz_id = %d 
        AND user_name = %s
    ";
    $row = $wpdb->get_row($wpdb->prepare($query,  $quiz_id, $user_name));
    if ($row) {
        $total_time = $current_time - $row->time;
        $existing_result = json_decode($row->result, true);
        if (is_array($existing_result)) {
            $question_found = false;
            foreach ($existing_result as &$existing_entry) {
                if ($existing_entry['question_id'] == $new_result['question_id']) {
                    $existing_entry = $new_result;
                    $question_found = true;
                    break;
                }
            }
            if (!$question_found) {
                $existing_result[] = $new_result;
            }
        } else {
            $existing_result = array($new_result);
        }
        $updated = $wpdb->update(
            $table_name,
            array(
                'total_time' => $total_time,
                'result'     => json_encode($existing_result), // Encode as JSON
            ),
            array('id' => $row->id) // Use the row's ID to identify it
        );

        // Log the update result
        if ($updated !== false) {
            wp_send_json_success('success');
        } else {
            wp_send_json_error('Error');
        }
    }
    wp_die();
}
add_action('wp_ajax_wiz_update_result_database_mcq', 'wiz_update_result_database_mcq');
add_action('wp_ajax_nopriv_wiz_update_result_database_mcq', 'wiz_update_result_database_mcq');

function wiz_update_result_database_drag()
{
    global $wpdb;
    $quiz_id = $_POST['wizQuizData']['quiz_id'];
    $user_name = $_POST['wizQuizData']['user_name'];
    $current_time = time();
    $result = $_POST['results'];
    $question_id = $_POST['question_id'];
    $total_option = get_post_meta($question_id, 'drag_&_drop', true);
    $gain_point = 0;

    for ($i = 0; $i < $total_option; $i++) {
        $answer_key = 'drag_&_drop_' . $i . '_answer';
        $answer = str_replace(' ', '', trim(get_post_meta($question_id, $answer_key, true)));
        $given_answer = str_replace(' ', '', trim($result[$i]['option']));
        if ($answer == $given_answer) {
            $gain_point++;
        }
    }

    $new_result = array(
        'question_id'  => $_POST['question_id'],
        'answer_given' => $_POST['results'],
        'correct'      => 'mixed',
        'total_point'  => $total_option,
        'gain_point'   => $gain_point,
    );

    // Prepare SQL query to get the row from the database
    $table_name = $wpdb->prefix . "wiz_results";
    $query = " SELECT *  FROM $table_name  WHERE quiz_id = %d  AND user_name = %s";
    $row = $wpdb->get_row($wpdb->prepare($query,  $quiz_id, $user_name));

    if ($row) {
        $total_time = $current_time - $row->time;
        $existing_result = json_decode($row->result, true);
        if (is_array($existing_result)) {
            $question_found = false;
            // Loop through the existing result to find the question and replace it if needed
            foreach ($existing_result as &$existing_entry) {
                if ($existing_entry['question_id'] == $new_result['question_id']) {
                    $existing_entry = $new_result;
                    $question_found = true;
                    break;
                }
            }
            // If the question is not found, add the new result
            if (!$question_found) {
                $existing_result[] = $new_result;
            }
        } else {
            $existing_result = array($new_result);
        }

        $updated = $wpdb->update(
            $table_name,
            array(
                'total_time' => $total_time,
                'result'     => json_encode($existing_result),
            ),
            array('id' => $row->id)
        );

        // Log the update result
        if ($updated !== false) {
            wp_send_json_success('success');
        } else {
            wp_send_json_error('Error');
        }
    }
    wp_die();
}
add_action('wp_ajax_wiz_update_result_database_drag', 'wiz_update_result_database_drag');
add_action('wp_ajax_nopriv_wiz_update_result_database_drag', 'wiz_update_result_database_drag');

function wiz_update_result_database_writting()
{
    global $wpdb;
    // Extract relevant data from $_POST 
    $quiz_id = $_POST['wizQuizData']['quiz_id'];
    $user_name = $_POST['wizQuizData']['user_name'];
    $term_id = $_POST['wizQuizData']['term_id'];
    $current_time = time();
    $given_answer = $_POST['answer'];
    $question_id = $_POST['question_id'];
    // Prepare SQL query to get the row from the database
    $table_name = $wpdb->prefix . "wiz_writting_results";
    $query = "
        SELECT * 
        FROM $table_name 
        WHERE quiz_id = %d 
        AND user_name = %s
    ";
    $row = $wpdb->get_row($wpdb->prepare($query,  $quiz_id, $user_name));
    if ($row) {
        $total_time = $current_time - $row->time;
        // Update the row in the database with the new result
        $updated = $wpdb->update(
            $table_name,
            array(
                'total_time' => $total_time,
                'result'     => $given_answer,
            ),
            array('id' => $row->id) // Use the row's ID to identify it
        );
        // Log the update result
        if ($updated !== false) {
            wp_send_json_success('success');
        } else {
            wp_send_json_error('Error');
        }
    }
    wp_die();
}
add_action('wp_ajax_wiz_update_result_database_writting', 'wiz_update_result_database_writting');
add_action('wp_ajax_nopriv_wiz_update_result_database_writting', 'wiz_update_result_database_writting');


function wiz_update_result_database_multiple()
{
    global $wpdb;
    $quiz_id = $_POST['wizQuizData']['quiz_id'];
    $user_name = $_POST['wizQuizData']['user_name'];
    $term_id = $_POST['wizQuizData']['term_id'];
    $current_time = time();
    $answers = $_POST['answers'];
    $question_id = $_POST['question_id'];
    $gain_point = 0;
    $total_option = get_post_meta($question_id, 'drop_down_options', true);

    for ($i = 0; $i < $total_option; $i++) {
        $answer_key = 'drop_down_options_' . $i . '_select_extract';
        $actual_answer = str_replace(' ', '', trim(get_post_meta($question_id, $answer_key, true)));
        $given_answer = str_replace(' ', '', trim($answers[$i]['answer']));
        if ($actual_answer == $given_answer) {
            $gain_point++;
        }
    }
    $new_result = array(
        'question_id'  => $_POST['question_id'],
        'answer_given' => $_POST['answers'],
        'correct'      => 'mixed',
        'total_point'  => $total_option,
        'gain_point'   => $gain_point,
    );
    //Prepare SQL query to get the row from the database
    $table_name = $wpdb->prefix . "wiz_results";
    $query = "
        SELECT * 
        FROM $table_name 
        WHERE quiz_id = %d 
        AND user_name = %s
    ";
    $row = $wpdb->get_row($wpdb->prepare($query,  $quiz_id, $user_name));
    if ($row) {
        $total_time = $current_time - $row->time;
        $existing_result = json_decode($row->result, true);
        if (is_array($existing_result)) {
            $question_found = false;
            // Loop through the existing result to find the question and replace it if needed
            foreach ($existing_result as &$existing_entry) {
                if ($existing_entry['question_id'] == $new_result['question_id']) {
                    $existing_entry = $new_result;  // Replace the existing entry with the new one
                    $question_found = true;
                    break;
                }
            }
            // If the question is not found, add the new result
            if (!$question_found) {
                $existing_result[] = $new_result;  // Add the new result
            }
        } else {
            $existing_result = array($new_result);  // If there's no existing result, start a new array
        }

        $updated = $wpdb->update(
            $table_name,
            array(
                'total_time' => $total_time,
                'result'     => json_encode($existing_result), // Encode as JSON
            ),
            array('id' => $row->id) // Use the row's ID to identify it
        );

        // Log the update result
        if ($updated !== false) {
            wp_send_json_success('success');
        } else {
            wp_send_json_error('Error');
        }
    }
    wp_die();
}
add_action('wp_ajax_wiz_update_result_database_multiple', 'wiz_update_result_database_multiple');
add_action('wp_ajax_nopriv_wiz_update_result_database_multiple', 'wiz_update_result_database_multiple');

<?php

/*
 * Plugin Name:      Wiz Quiz
* Plugin URI:        https://github.com/shakib6472/
* Description:       This plugin is to be used for Quiz Quiz
* Version:           1.0.0
* Requires at least: 5.2
* Requires PHP:      7.2
* Author:            Shakib Shown
* Author URI:        https://github.com/shakib6472/
* License:           GPL v2 or later
* License URI:       https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain:       wiz-quiz
* Domain Path:       /languages
*/
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('WIZ_QUIZ_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WIZ_QUIZ_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once WIZ_QUIZ_PLUGIN_DIR . 'ele/elementor-setup.php';
require_once WIZ_QUIZ_PLUGIN_DIR . 'setups.php';
require_once WIZ_QUIZ_PLUGIN_DIR . 'ajax.php';


/* Enqueue Assets */
function wiz_enqueue_assets()
{
    // Enqueue CSS
    wp_enqueue_style('wiz-quiz-toast-style', plugin_dir_url(__FILE__) . 'assets/css/toast.css', array(), '1.0.0', 'all');
    wp_enqueue_style('wiz-quiz-style', plugin_dir_url(__FILE__) . 'assets/css/style.css', array(), '1.0.0', 'all');

    wp_enqueue_script('jquery');
    wp_enqueue_script('wiz-quiz-script', plugin_dir_url(__FILE__) . 'assets/js/scripts.js', array('jquery'), '1.0.0', true); // Load after jQuery
    wp_enqueue_script('wiz-quiz-font-owsome-script',  'https://kit.fontawesome.com/46882cce5e.js', array('jquery'), '1.0.0', true); // Load after jQuery
    wp_enqueue_script('wiz-quiz-toast-script',  'https://cdn.jsdelivr.net/npm/jquery-toast-plugin@1.3.2/dist/jquery.toast.min.js', array('jquery'), '1.0.0', true); // Load after jQuery
    wp_enqueue_script('wiz-quiz-jq-ui-script',  'https://code.jquery.com/ui/1.13.2/jquery-ui.min.js', array('jquery'), '1.0.0', true); // Load after jQuery
    wp_enqueue_script('wiz-quiz-math-script',  'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js', array('jquery'), '1.0.0', true); // Load after jQuery

    // Localize the script with data
    wp_localize_script('wiz-quiz-script', 'ajax_object', array(
        'ajax_url'   => admin_url('admin-ajax.php'),  // Correct Ajax URL
        'result_url'   => home_url('/results'),                    // Correct Result page URL
        'home_url'   => home_url()                    // Correct Home URL
    ));
}
add_action('wp_enqueue_scripts', 'wiz_enqueue_assets');


// Activation hook
function wiz_activate_plugin()
{

    //create a table in the database
    global $wpdb;
    $table_name = $wpdb->prefix . "wiz_results";
    $sql = "CREATE TABLE $table_name (
    id int(11) NOT NULL AUTO_INCREMENT,
    user_name TEXT NOT NULL,
    user_id int(11) NOT NULL,
    device_id varchar(255) NOT NULL,
    quiz_id int(11) NOT NULL, 
    date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    quiz_type varchar(255) NOT NULL,
    quiz_type_id int(11) NOT NULL,
    total_time int(11) NOT NULL,
    time int(100) NOT NULL,
    result TEXT NOT NULL,
    user_agent TEXT NOT NULL,
    PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Writting Test
    $table_name = $wpdb->prefix . "wiz_writting_results";
    $sql = "CREATE TABLE $table_name (
    id int(11) NOT NULL AUTO_INCREMENT,
    user_name TEXT NOT NULL,
    user_id int(11) NOT NULL,
    device_id varchar(255) NOT NULL,
    quiz_id int(11) NOT NULL, 
    date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    quiz_type varchar(255) NOT NULL,
    quiz_type_id int(11) NOT NULL,
    total_time int(11) NOT NULL,
    time int(100) NOT NULL,
    term_id int(10) NOT NULL,
    total_point int(10) NOT NULL,
    gain_point int(10) NOT NULL,
    result TEXT NOT NULL,
    user_agent TEXT NOT NULL,
    PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    //create a table in the database
    $table_name = $wpdb->prefix . "wiz_quiz";
    $sql = "CREATE TABLE $table_name (
    id int(11) NOT NULL AUTO_INCREMENT,
    quiz_name varchar(255) NOT NULL,
    quiz_type varchar(255) NOT NULL,
    quiz_description varchar(255) NOT NULL,
    quiz_image varchar(255) NOT NULL,
    PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'wiz_activate_plugin');

// Deactivation hook
function wiz_deactivate_plugin()
{
    // Code to run when the plugin is deactivated

}
register_deactivation_hook(__FILE__, 'wiz_deactivate_plugin');

// Uninstall hook (if you want to clean up everything when the plugin is deleted)
function wiz_uninstall_plugin()
{
    // Clean up everything (e.g., database tables, options, etc.)

}
register_uninstall_hook(__FILE__, 'wiz_uninstall_plugin');

<?php

/**
 * Template result Page
 * 
 * @package Results
 */

// Get Header (this will include the <head> section and wp_head())
get_header();
global $wpdb;
// Main Section
$quiz_id = $_GET['quiz_id'];
$term_id = $_GET['term'];
//get term name( key ) by term id. 
$term_name = get_term($term_id)->name;
$term = get_term($term_id);
$tax = get_term($term_id)->taxonomy;

//Define Post Type name
if ($tax == 'reading-practice') {
    $quiz_name = 'Reading';
} else if ($tax == 'mathematical-reasoni') {
    $quiz_name = 'Mathematical Reasoning';
} else if ($tax == 'thinking-skill') {
    $quiz_name = 'Thinking Skill';
} else if ($tax == 'writtings-practice') {
    $quiz_name = 'Writting';
}

error_log(print_r($term, true));
if (is_user_logged_in()) {
    $user_id = get_current_user_id();
} else {
    $user_id = 0;
}

if ($tax != 'writtings-practice') {
    $existing_result = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}wiz_results WHERE quiz_id = %d AND user_id = %d",
        $quiz_id,
        $user_id
    ));
} else {
    error_log('It\'s a Writting Skill test');
}

error_log(print_r($existing_result, true));

$submitted_date = $existing_result->date;
$date_obj = new DateTime($date);
$formatted_date = $date_obj->format('D, d M Y');
?>

<div class="result_container">
    <!-- Header Section -->
    <header class="header">
        <h1 class="test-name text-center w-100">
            Selective High School Placement Test - <?php echo $term_name; ?> - <?php echo $quiz_name; ?>
        </h1>
    </header>
    <!-- Main Content -->
    <main>
        <!-- Summary Section -->
        <section class="summary-section">
            <h4 class="summary-header">Summary</h4>
            <p class="wiz_bold-text">Submitted Fri, 29 Nov 2024 @ 3:27pm</p>
            <div class="score-summary">
                <h2 class="score">10/30</h2>
                <h3 class="percentage">33.3%</h3>
            </div>
        </section>

        <!-- Question Results Section -->
        <section class="question-results">
            <h2>Question Results</h2>
            <p class="hint">Click a question to view your response in detail.</p>
            <div class="results-grid">
                <div class="question-box correct">1</div>
                <div class="question-box incorrect">2</div>
                <div class="question-box correct">3</div>
                <div class="question-box incorrect">4</div>
                <div class="question-box incorrect">5</div>
                <div class="question-box correct">6</div>
                <div class="question-box correct">7</div>
                <div class="question-box incorrect">8</div>
                <div class="question-box correct">9</div>
                <div class="question-box incorrect">10</div>
                <div class="question-box incorrect">11</div>
                <div class="question-box incorrect">12</div>
                <div class="question-box correct">13</div>
                <div class="question-box correct">14</div>
                <div class="question-box incorrect">15</div>
                <div class="question-box incorrect">16</div>
            </div>
        </section>

        <!-- Detailed Results Section -->
        <section class="detailed-results">
            <h2>Detailed Results</h2>
            <p>Click a question to view your response in detail.</p>
            <table class="results-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Type</th>
                        <th>Question</th>
                        <th>Result</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Bombay</td>
                        <td><a href="#">Bombay 01</a></td>
                        <td class="result correct">✔</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Bombay</td>
                        <td><a href="#">Bombay 02</a></td>
                        <td class="result incorrect">✘</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Bombay</td>
                        <td><a href="#">Bombay 03</a></td>
                        <td class="result correct">✔</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Bombay</td>
                        <td><a href="#">Bombay 03</a></td>
                        <td class="result half-correct">7/10</td>
                    </tr>
                    <!-- Add more rows as required -->
                </tbody>
            </table>
        </section>
    </main>
</div>
<?php

// Get Footer (this will include wp_footer() and closing tags)
get_footer();

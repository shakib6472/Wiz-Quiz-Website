<?php

/**
 * Template 
 * 
 * @package Wiz Quiz
 * @ All $posts 
 */

?>


<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">


<div class="option-container scrollbar">  
    <div id="editor"></div>
</div>
 
<script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
<script> 
    var quill = new Quill('#editor', {
        theme: 'snow',
        modules: {
            toolbar: [
                [{
                    'header': '1'
                }, {
                    'header': '2'
                }, {
                    'font': []
                }],
                [{
                    'list': 'ordered'
                }, {
                    'list': 'bullet'
                }],
                ['bold', 'italic', 'underline', 'strike'],
                [{
                    'align': []
                }],
                ['link'],
                ['blockquote', 'code-block'],
                [{
                    'script': 'sub'
                }, {
                    'script': 'super'
                }],
                ['image'],
                ['clean']
            ]
        },
        placeholder: 'Type your text here...'
    });

    // Disable spellcheck to prevent Grammarly interference
    document.getElementById('editor').setAttribute('spellcheck', 'false');
</script>

<div class="option-container scrollbar">

</div>

<?php

<?php

/**
 * Template for displaying the 'reading-practice' taxonomy archive page.
 * 
 * @package Wiz Quiz
 * @ main $post,  $post_id
 */

?>

<div class="option-container dragable-container scrollbar">
    <!-- Options -->
    <div class="options" id="options">

        <?php
        $total_option = get_post_meta($post_id, 'drag_&_drop', true);
        $total_ext_option = get_post_meta($post_id, 'extra_dragable_option', true);

        for ($i = 0; $i < $total_option; $i++) {
            $opt_key = 'drag_&_drop_' . $i . '_answer';
            $opt_name = get_post_meta($post_id, $opt_key, true);
        ?>
            <div class="drag_option" data-option-id="<?php echo $i; ?>">
                <?php echo $opt_name; ?>
            </div>

        <?php
        }
        for ($i = 0; $i < $total_ext_option; $i++) {
            $opt_key = 'extra_dragable_option_' . $i . '_extra_option';
            $opt_name = get_post_meta($post_id, $opt_key, true);
        ?>
            <div class="drag_option" data-option-id="<?php echo (floatval($total_option) + $i); ?>">
                <?php echo $opt_name; ?>
            </div>

        <?php
        }
        ?>
    </div>

    <!-- Answer Boxes -->
    <div class="answer-boxes" id="answer-boxes">
        <?php
        for ($i = 0; $i < $total_option; $i++) {
            $opt_key = 'drag_&_drop_' . $i . '_question';
            $opt_name = get_post_meta($post_id, $opt_key, true);
        ?>
           
            <div class="ans-group">
                <div class="group-name"> <?php echo $opt_name; ?> </div>
                <div class="answer-box" data-que-id="<?php echo $i; ?>">
                    <span class="placeholder">Drop here</span>
                </div>
            </div>
        <?php
        }
        ?>

    </div>
</div>
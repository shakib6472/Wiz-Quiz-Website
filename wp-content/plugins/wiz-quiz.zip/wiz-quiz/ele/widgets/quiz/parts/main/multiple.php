<?php

/**
 * Template 
 * 
 * @package Wiz Quiz
 * @ All $post, $post_id
 */

?>

<!-- Multiple  -->

<div class="option-container scrollbar">
    <?php
    $total_option = get_post_meta($post_id, 'drop_down_options', true);

    for ($i = 0; $i < $total_option; $i++) {
        $opt_key = 'drop_down_options_' . $i . '_question_text';
        $opt_name = get_post_meta($post_id, $opt_key, true);
    ?>
        <div class="q-multipl-bg">
            <div class="question-row">
                <label for="q<?php echo $post_id . $i; ?>"> <?php echo $opt_name; ?> </label>
                <select data-index="<?php echo $i; ?>" id="q<?php echo $post_id . $i; ?>" name="q<?php echo $post_id . $i; ?>">
                    <option value=""  selected disabled> -- Select --</option>
                    <?php
                    for ($j = 0; $j < $total_extract; $j++) {
                        $ext_key = 'add_extracts_' . $j . '_extract_name';
                        $ext_name = get_post_meta($post_id, $ext_key, true); ?>
                        <option value="<?php echo $ext_name; ?>"><?php echo $ext_name; ?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
        </div>
    <?php
    }
    ?>
</div>
<?php

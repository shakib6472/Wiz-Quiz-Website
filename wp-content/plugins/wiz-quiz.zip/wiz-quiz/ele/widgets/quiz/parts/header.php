<header>
    <div class="header">
        <div class="zoom">
            <div class="btn">
                <i class="fas fa-magnifying-glass-plus"></i>
                <div class="zoom-options">
                    <div class="option active" data-per="100">100%</div>
                    <div class="option" data-per="150">150%</div>
                    <div class="option" data-per="175">175%</div>
                    <div class="option" data-per="200">200%</div>
                    <div class="option" data-per="250">250%</div>
                    <div class="option" data-per="275">275%</div>
                    <div class="option" data-per="300">300%</div>
                </div>
            </div>
        </div>
        <div class="title-area">
            <h2 class="instruction">Instructions</h2>
            <i class="fas fa-grip pagination-page"> </i>
        </div>
        <div class="logo">
            <img
                src="https://insights2prodp44s3w.azureedge.net/uploads/se-practice/testplayerthemeassets/0ce7d126-0943-ef11-8d1f-c7323addf5da/a76b7581-9e95-ef11-8b1a-8ec111fe82e5.png"
                alt="" />
        </div>
    </div>
</header>
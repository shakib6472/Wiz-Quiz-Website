<?php

/**
 * Template for displaying the 'reading-practice' taxonomy archive page.
 * 
 * @package Wiz Quiz
 * @ All $posts 
 */

?>

<main>
    <div class="information scrollbar">
        <!-- Information Area - Should Came From Practice Description -->
        <?php require_once WIZ_QUIZ_PLUGIN_DIR . 'ele/widgets/quiz/parts/info.php'; ?>
    </div>


    <!-- Slides -->



    <?php
    // error_lg post for each 
    $post_slide = 0;
    foreach ($posts as $post) {
        $post_slide++;
        $post_id = get_the_ID();
        $post_title = get_the_title($post_id);
        // Get all meta data for the post
        $post_meta = get_post_meta($post_id);
        foreach ($post_meta as $meta_key => $meta_values) {
            // error_log('Meta Key: ' . $meta_key . ' | Meta Value: ' . implode(', ', $meta_values));
        }
        $question_type = get_post_meta($post_id, 'question_type', true);
        $total_extract = get_post_meta($post_id, 'add_extracts', true);
        $total_option = get_post_meta($post_id, 'mcq_options_', true);

    ?>
        <div class="slides slide-<?php echo $post_slide; ?>" data-que-type="<?php echo $question_type; ?>" data-slide="<?php echo $post_slide; ?>" data-que="<?php echo $post_id; ?>">
            <div class="contents" tabindex="0">
                <div class="left" tabindex="1">
                    <div class="extracts" tabindex="2">
                        <div class="extract-heads">
                            <?php
                            for ($i = 0; $i < $total_extract; $i++) {
                                $ext_key = 'add_extracts_' . $i . '_extract_name';
                                $ext_name = get_post_meta($post_id, $ext_key, true);
                            ?>
                                <div class="heads<?php echo ($i == 0) ? ' active' : ''; ?>" data-extract="add_extracts_<?php echo $i; ?>"><?php echo $ext_name; ?></div>
                            <?php
                            }

                            ?>
                        </div>
                        <div class="extract-bodys scrollbar">
                            <?php
                            for ($i = 0; $i < $total_extract; $i++) {
                                $extb_key = 'add_extracts_' . $i . '_extract_details';
                                $extb_name = get_post_meta($post_id, $extb_key, true);
                            ?>
                                <div class="bodys<?php echo ($i == 0) ? ' active' : ''; ?>" data-extract="add_extracts_<?php echo $i; ?>">
                                    <?php echo $extb_name; ?>
                                </div>
                            <?php
                            }
                            ?>

                        </div>
                    </div>
                </div>

                <div class="middle">
                    <div class="close-icon">
                        <i class="fas fa-caret-right"></i>
                    </div>
                    <div class="open-icon">
                        <i class="fas fa-caret-left"></i>
                    </div>
                </div>


                <div class="right">

                    <div class="question">
                        <h3><?php echo get_post_meta($post_id, 'question_texts', true); ?></h3>
                    </div>
                    <div class="q-options">
                        <?php

                        if ('MCQ' === $question_type) {
                            error_log(' Verified Question Type: ' . $question_type);
                            // require_once WIZ_QUIZ_PLUGIN_DIR . 'ele/widgets/quiz/parts/main/mcq.php';
                        ?>

                            <div class="option-container scrollbar"> 
                                <?php
                                for ($mcindex = 0; $mcindex < $total_option; $mcindex++) {
                                    error_log('MC Index: ' . $mcindex);
                                    $opt_key = 'mcq_options__' . $mcindex . '_mcq_option';
                                    $opt_name = get_post_meta($post_id, $opt_key, true);
                                ?>
                                    <label for="q_<?php echo $post_id; ?>_option_<?php echo $mcindex; ?>" class="option" data-ans="1" data-que="<?php echo $post_id; ?>">
                                        <input type="radio" value="<?php echo $opt_name; ?>" id="q_<?php echo $post_id; ?>_option_<?php echo $mcindex; ?>" name="q<?php echo $post_id; ?>-ans" />
                                        <?php echo $opt_name; ?>
                                    </label>
                                <?php
                                }
                                ?> 
                            </div>
                        <?php
                        } else if ('Drag & Drop' === $question_type) {
                            require_once WIZ_QUIZ_PLUGIN_DIR . 'ele/widgets/quiz/parts/main/drag.php';
                        } else if ('Multiple Drop Down' === $question_type) {
                            require_once WIZ_QUIZ_PLUGIN_DIR . 'ele/widgets/quiz/parts/main/multiple.php';
                        } else if ('Writings' === $question_type) {
                            require_once WIZ_QUIZ_PLUGIN_DIR . 'ele/widgets/quiz/parts/main/writting.php';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

    <?php
    }
    ?>
</main>
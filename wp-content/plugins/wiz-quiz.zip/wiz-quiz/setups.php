<?php

function wiz_quiz_main_template($template)
{
    // Check if we're on the 'reading-practice' taxonomy archive page
    if (is_tax('reading-practice') || is_tax('mathenatical-practice') || is_tax('thinking-skll-practice') || is_tax('writtings-practice')) {
        // Define the path to your custom template  
        $quiz_template = WIZ_QUIZ_PLUGIN_DIR . 'ele/widgets/quiz/quiz.php';

        // Check if the template exists, then use it
        if (file_exists($quiz_template)) {
            return $quiz_template;
        } else {
            // Log a message if the template is not found
            echo 'Template not found';
        }
    }
    if (is_page('results')) {
        $result_template = WIZ_QUIZ_PLUGIN_DIR . 'ele/widgets/result.php';
        
        // Check if the result template exists
        if (file_exists($result_template)) {  
            return $result_template; 
        } else {
            // Log a message if the template is not found
            echo 'Result template not found';
        }
    }

    // Return the default template if no custom template is found
    return $template;
}
add_filter('template_include', 'wiz_quiz_main_template',99);
